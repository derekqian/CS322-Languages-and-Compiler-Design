// Output created by jacc on Fri Jan 04 11:11:11 PST 2013

interface DCTokens {
    int ENDINPUT = 0;
    int ELSE = 1;
    int EQEQ = 2;
    int IF = 3;
    int INTLIT = 4;
    int PRINT = 5;
    int VAR = 6;
    int WHILE = 7;
    int error = 8;
    // '(' (code=40)
    // ')' (code=41)
    // '+' (code=43)
    // '-' (code=45)
    // ';' (code=59)
    // '<' (code=60)
    // '=' (code=61)
    // '{' (code=123)
    // '}' (code=125)
}
